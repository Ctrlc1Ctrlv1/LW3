//#include <iostream>
//#include <fstream>
//using namespace std;
//
//
//int main() {
//    std::cout << "Hello, World!" << std::endl;
//    system("chcp 65001");
//    setlocale(LC_ALL,"Ukrainian");
//
////    ofstream fout("cppstudio.txt"); // создаём объект класса ofstream для записи и связываем его с файлом cppstudio.txt
////    fout << "Работа з файлами в С++"; // запись строки в файл
////    fout.close(); // закрываем файл
//
//    char buff[50]; // буфер промежуточного хранения считываемого из файла текста
//    ifstream fin("cppstudio.txt"); // открыли файл для чтения
//
//    fin >> buff; // считали первое слово из файла
//    cout << buff << endl; // напечатали это слово
//
//    fin.getline(buff, 50); // считали строку из файла
//    fin.close(); // закрываем файл
//    cout << buff << endl; // напечатали эту строку
//
//
//    system("pause");
//    return 0;
//}

#include <iostream>
#include <fstream>
#include <string>

int main() {
    // Open the file
    std::ifstream inputFile("cppstudio.txt");

    // Check if the file was successfully opened
    if (!inputFile.is_open()) {
        std::cerr << "Error opening file 'cppstudio.txt'" << std::endl;
        return 1;
    }

    // Variable to hold the first word
    std::string firstWord;

    // Read the first word from the file
    inputFile >> firstWord;

    // Check if a word was successfully read
    if (firstWord.empty()) {
        std::cerr << "File 'cppstudio.txt' is empty or contains no words" << std::endl;
        inputFile.close();
        return 1;
    }

    // Output the first word to the console
    std::cout << "The first word in the file is: " << firstWord << std::endl;

//    char buff[50]; // буфер промежуточного хранения считываемого из файла текста
//    inputFile.getline(buff,50);
//    std::cout << buff << std::endl;
    // Close the file
    inputFile.close();

    return 0;
}

